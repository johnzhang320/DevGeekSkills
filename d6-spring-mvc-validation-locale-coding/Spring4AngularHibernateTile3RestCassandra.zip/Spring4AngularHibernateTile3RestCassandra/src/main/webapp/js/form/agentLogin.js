
 	 /**
 	 *  Encrypt password if leave password text box
 	 */
 	stringCryption.initialize("password"); 		  
 	
 	function loginSubmitForm() { 	
 		//document.forms['agentTable'].action='agentLogin.html';
 		document.forms['agentTable'].submit();
 	}
 	