package com.frontend.encrypt.utils;

public interface Constants {
	public static int KEY_LENGTH=1024;
	public static String KEY_PAIR="keys";
}
