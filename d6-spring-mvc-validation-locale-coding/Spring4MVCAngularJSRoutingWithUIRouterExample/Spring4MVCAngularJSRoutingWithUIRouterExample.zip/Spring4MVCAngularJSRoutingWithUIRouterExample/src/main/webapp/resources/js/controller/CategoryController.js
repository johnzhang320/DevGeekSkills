'use strict';

App.controller('CategoryController', ['async', function(async) {
          var self = this;
          self.categories=async;
}]);
