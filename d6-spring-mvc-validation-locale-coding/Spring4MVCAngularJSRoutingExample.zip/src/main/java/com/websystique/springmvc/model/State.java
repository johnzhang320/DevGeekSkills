package com.websystique.springmvc.model;

public enum State {

	NEW,USED;
}
